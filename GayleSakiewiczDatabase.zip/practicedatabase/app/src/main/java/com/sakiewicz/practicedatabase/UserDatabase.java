package com.sakiewicz.practicedatabase;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class UserDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "user.db";

    private static UserDatabase mUserDb;



    public static UserDatabase getInstance(Context context) {
        if (mUserDb == null) {
            mUserDb = new UserDatabase(context);
        }
        return mUserDb;
    }

    private UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }



    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "userName";
        private static final String COL_PASSWORD = "password";

    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Create items table
        db.execSQL("create table " + UserDatabase.UserTable.TABLE + " (" +
                UserDatabase.UserTable.COL_ID + " integer primary key autoincrement, " +
                UserDatabase.UserTable.COL_NAME + " TEXT, " +
                UserDatabase.UserTable.COL_PASSWORD + " TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists " + UserDatabase.UserTable.TABLE);
        onCreate(db);
    }



    public boolean addUserBool(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.UserTable.COL_NAME, user.getUserName());
        values.put(UserDatabase.UserTable.COL_PASSWORD, user.getPassword());
        long id = db.insert(UserDatabase.UserTable.TABLE, null, values);
        return id != -1;
    }





    @SuppressLint("Range")
    public boolean checkLogin(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Boolean userExists = false;
        String index = UserTable.COL_NAME;
        Cursor cursor = db.rawQuery("SELECT * FROM " + UserTable.TABLE, null);
        if (cursor != null && cursor.getCount() > 0){
            cursor.moveToFirst();
            do {
                if(cursor.getString(cursor.getColumnIndex(index)).equals(username)){
                    if (password.equals(cursor.getColumnIndex(UserTable.COL_PASSWORD))){
                        userExists = true;
                        break;
                    }

                }
            }while(cursor.moveToNext());
        };
        cursor.close();
        db.close();
        return userExists;
    }





}

package com.sakiewicz.practicedatabase;

public class Item {

    private long mId;
    private String mName;
    private String mQuantity;
    //private String mSubject;
    public Item() {}

    public Item(String name, String quantity){
        mName = name;
        mQuantity = quantity;
    }


    public String getName() {
        return mName;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getId() {
        return mId;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String getQuantity() {
        return mQuantity;
    }

    public void setQuantity(String quantity) {
        this.mQuantity = quantity;
    }

   // public String getSubject() {
   //     return mSubject;
   // }

  //  public void setSubject(String subject) {
   //     this.mSubject = subject;
   // }
}

package com.sakiewicz.practicedatabase;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import android.view.ActionMode;

public class InventoryActivity extends AppCompatActivity
         {

    // public static String EXTRA_ID = "com.example.sakiewiczdatabaseapp.ID";
    public static String EXTRA_ADD_NAME = "com.example.sakiewiczdatabaseapp.ID";
    public static String EXTRA_ADD_QUANTITY = "com.example.sakiewiczdatabaseapp.ID";
    private ItemDatabase mItemDb;
    private Item mSelectedItem;
    private int mSelectedItemPosition = RecyclerView.NO_POSITION;
    private ActionMode mActionMode = null;
    private ItemAdapter itemAdapter;
    private RecyclerView mRecyclerView;
    private int[] mSubjectColors;
    private ItemAdapter mItemAdapter;
    private ArrayList<Item> itemArrayList;
    String addName, addQuant;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject);




        mSubjectColors = getResources().getIntArray(R.array.subjectColors);


        // Singleton
        mItemDb = ItemDatabase.getInstance(getApplicationContext());

        mRecyclerView = findViewById(R.id.itemRecyclerView);
        Intent addIntent = getIntent();
        String addName = addIntent.getStringExtra(AddItem.EXTRA_ADD_NAME);
        String addQuant = addIntent.getStringExtra(AddItem.EXTRA_ADD_QUANTITY);

        // Create 2 grid layout columns
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);


        itemArrayList = new ArrayList<>();
        itemArrayList = mItemDb.getItems();

        ItemAdapter mItemAdapter = new ItemAdapter(itemArrayList, this);
        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        mRecyclerView.setLayoutManager(layoutManager);

        mRecyclerView.setAdapter(mItemAdapter);


    }



    public void addItemClick(View view){
        Intent goAdd = new Intent(InventoryActivity.this, AddItem.class);
        startActivity(goAdd);

    }

    public void addItem(String name, String quant) {
        name = addName;
        quant = addQuant;
        Item item = new Item();
        item.setName(name);
        item.setQuantity(quant);
        itemArrayList.add(0, item);
        //notifyItemInserted(0);
        Toast.makeText(InventoryActivity.this,
                "Item added", Toast.LENGTH_LONG).show();
        mRecyclerView.scrollToPosition(0);
    }



    private ActionMode.Callback mActionModeCallback = new ActionMode.Callback() {

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            // Provide context menu for CAB
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.context_menu, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            // Process action item selection
            switch (item.getItemId()) {
                case R.id.delete:
                    // Delete from the database and remove from the RecyclerView
                    mItemDb.deleteItem(mSelectedItem.getId());
                    mItemAdapter.removeItem(mSelectedItem);

                    // Close the CAB
                    mode.finish();
                    return true;
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            mActionMode = null;

            // CAB closing, need to deselect item if not deleted
            mItemAdapter.notifyItemChanged(mSelectedItemPosition);
            mSelectedItemPosition = RecyclerView.NO_POSITION;
        }
    };
}






package com.sakiewicz.practicedatabase;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class ItemActivity extends AppCompatActivity {

    public static final String EXTRA_ITEM = "com.sakiewicz.practicedatabase.item";
    private final int REQUEST_CODE_NEW_ITEM = 0;
    private final int REQUEST_CODE_UPDATE_ITEM = 1;

    private ItemDatabase mItemDb;
    private String mItem;
    private List<Item> mItemList;
    private TextView mNameLabel;
    private TextView mNameText;
    //private Button mButton;
    private TextView mItemText;
    private int mCurrentItemIndex;
    private ViewGroup mShowItemsLayout;
    private ViewGroup mNoItemsLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);
/*        // Hosting activity provides the subject of the questions to display
        Intent intent = getIntent();
        mItem = intent.getStringExtra(EXTRA_ITEM);

      *//*  // Load all questions for this subject
        mItemDb = ItemDatabase.getInstance(getApplicationContext());
        mItemList = mItemDb.getItems(mItem);

        mItemText = findViewById(R.id.itemText);
        mNameLabel = findViewById(R.id.nameLabel);
        mQuantityText = findViewById(R.id.quantityText);
        //mAnswerButton = findViewById(R.id.answerButton);
        mShowItemsLayout = findViewById(R.id.showItemsLayout);
        mNoItemsLayout = findViewById(R.id.noItemsLayout);
*//*
        // Show first question
        showItem(0);
    }

    @Override
    protected void onStart() {
        super.onStart();

        // Are there questions to display?
        if (mItemList.size() == 0) {
            updateAppBarTitle();
            displayItem(false);
        } else {
            displayItem(true);
            //toggleAnswerVisibility();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate menu for the app bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.item_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Determine which app bar item was chosen
        switch (item.getItemId()) {
            case R.id.previous:
                showItem(mCurrentItemIndex - 1);
                return true;
            case R.id.next:
                showItem(mCurrentItemIndex + 1);
                return true;
            case R.id.add:
                addItem();
                return true;
            case R.id.edit:
                editItem();
                return true;
            case R.id.delete:
                deleteItem();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void addItemButtonClick(View view) {
        addItem();
    }

   *//* public void answerButtonClick(View view) {
        toggleAnswerVisibility();
    }*//*

    private void displayItem(boolean display) {

        // Show or hide the appropriate screen
        if (display) {
            mShowItemsLayout.setVisibility(View.VISIBLE);
            mNoItemsLayout.setVisibility(View.GONE);
        } else {
            mShowItemsLayout.setVisibility(View.GONE);
            mNoItemsLayout.setVisibility(View.VISIBLE);
        }
    }

    private void updateAppBarTitle() {

        // Display subject and number of questions in app bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            String title = getResources().getString(R.string.item_number,
                    "Item", mCurrentItemIndex + 1, mItemList.size());
            setTitle(title);
        }
    }

    *//*private void addItem() {
        // TODO: Add question
        Intent intent = new Intent(ItemActivity.this, ItemEditActivity.class);
        intent.putExtra(EXTRA_ITEM, mItem);
        startActivityforResult(intent, REQUEST_CODE_NEW_ITEM);
    }*//*

    *//*private void editItem() {
        // TODO: Edit question
        if (mCurrentItemIndex >= 0){
            Intent intent = new Intent(this, ItemEditActivity.class);
           // intent.putExtra(EXTRA_ITEM, mItem);
            long questionId = mItemList.get(mCurrentItemIndex).getId();
            intent.putExtra(ItemEditActivity.EXTRA_ITEM_ID, itemId);
            startActivityForResult(intent, REQUEST_CODE_UPDATE_ITEM);
        }
    }*//*

    private void deleteItem() {
        // TODO: Delete question
        if (mCurrentItemIndex >= 0) {
            long questionId = mItemList.get(mCurrentItemIndex).getId();
            mItemDb.deleteItem(questionId);
            mItemList.remove(mCurrentItemIndex);

            if (mItemList.size() == 0) {
                // No questions left to show
                mCurrentItemIndex = -1;
                updateAppBarTitle();
                displayItem(false);
            }
            else {
                showItem(mCurrentItemIndex);
            }

            Toast.makeText(this, R.string.item_deleted, Toast.LENGTH_SHORT).show();
        }
    }

   *//* private void showItem(int itemIndex) {

        // Show question at the given index
        if (mItemList.size() > 0) {
            if (itemIndex < 0) {
                itemIndex = mItemList.size() - 1;
            } else if (itemIndex >= mItemList.size()) {
                itemIndex = 0;
            }

            mCurrentItemIndex = itemIndex;
            updateAppBarTitle();

            Item item = mItemList.get(mCurrentItemIndex);
            mItemName.setText(item.getName());
            mQuantityText.setText(item.getQuantity());
        }
        else {
            // No questions yet
            mCurrentItemIndex = -1;
        }
    }*//*

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE_NEW_ITEM) {
            // Get added question
            long itemId = data.getLongExtra(ItemEditActivity.EXTRA_ITEM_ID, -1);
            Item newItem = mItemDb.getItem(itemId);

            // Add newly created question to the question list and show it
            mItemList.add(newItem);
            showItem(mItemList.size() - 1);

            Toast.makeText(this, R.string.item_added, Toast.LENGTH_SHORT).show();
        }
        else if (resultCode == RESULT_OK && requestCode == REQUEST_CODE_UPDATE_ITEM) {
            // Get updated question
            long itemId = data.getLongExtra(ItemEditActivity.EXTRA_ITEM_ID, -1);
            Item updatedItem = mItemDb.getItem(itemId);

            // Replace current question in question list with updated question
            Item currentItem = mItemList.get(mCurrentItemIndex);
            currentItem.setName(updatedItem.getName());
            currentItem.setQuantity(updatedItem.getQuantity());
            showItem(mCurrentItemIndex);

            Toast.makeText(this, R.string.item_updated, Toast.LENGTH_SHORT).show();
        }
    }*/

   /* private void toggleAnswerVisibility() {
        if (mAnswerText.getVisibility() == View.VISIBLE) {
            mAnswerButton.setText(R.string.show_answer);
            mAnswerText.setVisibility(View.INVISIBLE);
            mAnswerLabel.setVisibility(View.INVISIBLE);
        }
        else {
            mAnswerButton.setText(R.string.hide_answer);
            mAnswerText.setVisibility(View.VISIBLE);
            mAnswerLabel.setVisibility(View.VISIBLE);
        }
    }*/
}}

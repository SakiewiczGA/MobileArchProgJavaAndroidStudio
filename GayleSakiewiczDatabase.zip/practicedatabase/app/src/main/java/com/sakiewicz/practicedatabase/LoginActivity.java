package com.sakiewicz.practicedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private UserDatabase userDB;
    TextInputEditText editUsername, editPassword;
    Button btnLogin, btnRegister;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        userDB = UserDatabase.getInstance(getApplicationContext());

        editUsername = (TextInputEditText) findViewById(R.id.editUsername);
        editPassword = (TextInputEditText) findViewById(R.id.editPassword);
        btnLogin = (Button) findViewById(R.id.buttonLogin);
        btnRegister = (Button) findViewById(R.id.buttonRegister);
        AddUser();
        AuthenticateUser();

    }

    public void AddUser() {
        btnRegister.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String name = (editUsername.getText().toString());
                        String pword = (editPassword.getText().toString());
                        User user = new User(name, pword);
                        boolean isInserted = userDB.addUserBool(user);

                        if (isInserted) {
                            Toast.makeText(LoginActivity.this, "User Added", Toast.LENGTH_LONG).show();
                            //go to alert activity
                            Intent myIntent = new Intent(LoginActivity.this, InventoryActivity.class);
                            startActivity(myIntent);

                        } else {
                            Toast.makeText(LoginActivity.this, "User not Added", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }

    public void AuthenticateUser() {
        btnLogin.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        String username = editUsername.getText().toString();
                        String password = editPassword.getText().toString();
                        boolean isUser = userDB.checkLogin(username, password);
                        if (isUser) {

                            Intent myIntent = new Intent(LoginActivity.this, InventoryActivity.class);
                            startActivity(myIntent);

                        } else {

                            Toast.makeText(LoginActivity.this, "Username and/or password incorrect", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }
}
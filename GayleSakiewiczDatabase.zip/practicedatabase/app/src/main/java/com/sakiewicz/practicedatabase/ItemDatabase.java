package com.sakiewicz.practicedatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import java.util.ArrayList;
import java.util.List;

public class ItemDatabase extends SQLiteOpenHelper{

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "item.db";

    private static ItemDatabase mItemDb;

    public enum SubjectSortOrder { ALPHABETIC, UPDATE_DESC, UPDATE_ASC };

    public static ItemDatabase getInstance(Context context) {
        if (mItemDb == null) {
            mItemDb = new ItemDatabase(context);
        }
        return mItemDb;
    }

    private ItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    /*private static final class SubjectTable {
        private static final String TABLE = "items";
        private static final String COL_NAME = "t";
        private static final String COL_UPDATE_TIME = "updated";
    }*/

    private static final class ItemTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
        //private static final String COL_SUBJECT = "subject";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

         //Create items table
        db.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_NAME + " TEXT, " +
                ItemTable.COL_QUANTITY + " TEXT)");

        // Create questions table with foreign key that cascade deletes
       /* db.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_NAME + " TEXT, " +
                ItemTable.COL_QUANTITY + "TEXT " +
                //QuestionTable.COL_SUBJECT + ", " +
                //"foreign key(" + QuestionTable.COL_SUBJECT + ") references " +
                ItemTable.TABLE + "(" + ItemTable.COL_NAME + ") on delete cascade)");*/

    /*    // Add some subjects
        String[] subjects = { "History", "Math", "Computing" };
        for (String sub: subjects) {
            Subject subject = new Subject(sub);
            ContentValues values = new ContentValues();
            values.put(SubjectTable.COL_TEXT, subject.getText());
            values.put(SubjectTable.COL_UPDATE_TIME, subject.getUpdateTime());
            db.insert(SubjectTable.TABLE, null, values);
        }*/
        //add an item
        Item item = new Item();
        item.setName("This");
        item.setQuantity("7");
        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());

        db.insert(ItemTable.TABLE, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       // db.execSQL("drop table if exists " + SubjectTable.TABLE);
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

   /* @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }*/

   /* public List<Item> getitems(ItemSortOrder order) {
        List<Item> items = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String orderBy;
        switch (order) {
            case ALPHABETIC:
                orderBy = SubjectTable.COL_TEXT + " collate nocase";
                break;
            case UPDATE_DESC:
                orderBy = SubjectTable.COL_UPDATE_TIME + " desc";
                break;
            default:
                orderBy = SubjectTable.COL_UPDATE_TIME + " asc";
                break;
        }*/

      /*  String sql = "select * from " + SubjectTable.TABLE + " order by " + orderBy;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                Subject subject = new Subject();
                subject.setText(cursor.getString(0));
                subject.setUpdateTime(cursor.getLong(1));
                subjects.add(subject);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return subjects;
    }

    public boolean addSubject(Subject subject) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(SubjectTable.COL_TEXT, subject.getText());
        values.put(SubjectTable.COL_UPDATE_TIME, subject.getUpdateTime());
        long id = db.insert(SubjectTable.TABLE, null, values);
        return id != -1;
    }

    public void updateSubject(Subject subject) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(SubjectTable.COL_TEXT, subject.getText());
        values.put(SubjectTable.COL_UPDATE_TIME, subject.getUpdateTime());
        db.update(SubjectTable.TABLE, values,
                SubjectTable.COL_TEXT + " = ?", new String[] { subject.getText() });
    }

    public void deleteSubject(Subject subject) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(SubjectTable.TABLE,
                SubjectTable.COL_TEXT + " = ?", new String[] { subject.getText() });
    }*/

    public boolean addItemBool(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());
        long id = db.insert(ItemTable.TABLE, null, values);
        return id != -1;
    }

    public ArrayList<Item> getItems() {
        ArrayList<Item> items = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + ItemTable.TABLE;
              //  " where " + ItemTable.COL_NAME + " = ?";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setId(cursor.getInt(0));
                item.setName(cursor.getString(1));
                item.setQuantity(cursor.getString(2));
               // question.setSubject(cursor.getString(3));
                items.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return items;
    }

    public Item getItem(long itemId) {
        // Item item = null;
        Item item;
        String notFound = "Item not found";

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + ItemTable.TABLE +
                " where " + ItemTable.COL_ID + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{Float.toString(itemId)});

        if (cursor.moveToFirst()) {
            item = new Item();
            item.setId(cursor.getInt(0));

            item.setName(cursor.getString(1));
            item.setQuantity(cursor.getString(2));

            //item.setSubject(cursor.getString(3));


            return (item);
        }
        else{
            return null;
        }
    }


    public void addItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());
        //values.put(ItemTable.COL_SUBJECT, question.getSubject());
        long itemId = db.insert(ItemTable.TABLE, null, values);
        //long id = db.insert(ItemTable.TABLE, null, values);
        item.setId(itemId);

        // Change update time in subjects table
       // updateSubject(new Subject(item.getSubject()));
    }

    public void updateItem(Item item) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_ID, item.getId());
        values.put(ItemTable.COL_NAME, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());
       // values.put(QuestionTable.COL_SUBJECT, question.getSubject());
        db.update(ItemTable.TABLE, values,
                ItemTable.COL_ID + " = " + item.getId(), null);

        // Change update time in subjects table
       // updateSubject(new Subject(question.getSubject()));
    }

    public void deleteItem(long itemId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ItemTable.TABLE,
                ItemTable.COL_ID + " = " + itemId, null);
    }
}




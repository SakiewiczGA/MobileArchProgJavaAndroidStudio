package com.sakiewicz.practicedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;

public class AddItem extends AppCompatActivity {

    ItemDatabase itemDb;
    TextInputEditText editItemName, editItemQuantity;
    Button btnAddItem;
    public static String EXTRA_ADD_NAME;
    public static String EXTRA_ADD_QUANTITY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Add Item");

        setContentView(R.layout.activity_add_item);
        editItemName = (TextInputEditText) findViewById(R.id.editItemName);
        editItemQuantity = (TextInputEditText) findViewById(R.id.editItemQuantity);
        btnAddItem = (Button) findViewById(R.id.button_add);
        AddItem();

    }

    public void AddItem(){
        btnAddItem.setOnClickListener(
                new View.OnClickListener() {


                    @Override
                    public void onClick(View view) {

                        String name = editItemName.getText().toString();
                        String quant = editItemQuantity.getText().toString();
                        if((name.length() > 0) && (quant.length() >0)) {

                            Intent intent = new Intent(AddItem.this, InventoryActivity.class);
                            intent.putExtra(EXTRA_ADD_NAME, name);
                            intent.putExtra(EXTRA_ADD_QUANTITY, quant);
                            startActivity(intent);
                        }
                        else{
                            Intent intent = new Intent(AddItem.this, InventoryActivity.class);
                            startActivity(intent);

                        }



                    }

                }

        );
    }
}
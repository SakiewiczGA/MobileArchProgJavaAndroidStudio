package com.sakiewicz.practicedatabase;

import android.content.Context;
import android.content.Intent;
//import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.MyItemHolder> {

    private ArrayList<Item> itemArrayList;


    ArrayList itemNames;
    ArrayList itemQuants;
    Context context;

    public ItemAdapter(ArrayList<Item> recyclerArrayList, Context context){
        this.itemArrayList = recyclerArrayList;
        this.context = context;
    }


    @NonNull
    @Override
    public MyItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_items, parent, false);
        return new MyItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyItemHolder holder, int position){
        Item item = itemArrayList.get(position);
        holder.name.setText(item.getName());
        holder.quant.setText(item.getQuantity());
    }

    @Override
    public int getItemCount(){
        return itemArrayList.size();
    }
    public class MyItemHolder extends RecyclerView.ViewHolder{
        private TextView name;
        private TextView quant;

        public MyItemHolder(@NonNull View itemView){
            super(itemView);
            name = itemView.findViewById(R.id.itemTextView);
            quant = itemView.findViewById(R.id.itemQuantView);
        }
    }


    public void removeItem(Item item) {
        int index = itemArrayList.indexOf(item);
        if (index >= 0) {
            itemArrayList.remove(index);
            notifyItemRemoved(index);
        }



    }




}

package com.sakiewicz.practicedatabase;

public class User {
    int _id;
    String _userName;
    String _password;

    public User(){}
    public User(int id, String name, String password){
        this._id = id;
        this._userName = name;
        this._password = password;
    }

    public User(String name, String password){
        this._userName = name;
        this._password = password;
    }

    public int getId(){return this._id;}
    public String getUserName(){return this._userName;}
    public String getPassword(){return this._password;}
    public void setId(int id){this._id = id;}
    public void setUserName(String name){this._userName = name;}
    public void setPassword(String password){this._password = password;}






}

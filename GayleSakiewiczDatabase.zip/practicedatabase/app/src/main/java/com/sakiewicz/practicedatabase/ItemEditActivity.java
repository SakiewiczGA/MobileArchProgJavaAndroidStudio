package com.sakiewicz.practicedatabase;

import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.READ_SMS;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.Intent;
import androidx.appcompat.app.ActionBar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.EditText;


public class ItemEditActivity extends AppCompatActivity {
    public static final String EXTRA_ITEM_ID = "com.zybooks.studyhelper.question_id";

    String number;
    private EditText mItemName;
    private EditText mItemQuantity;
    private String mItemGetName;
    private String mItemGetQuant;

    private ItemDatabase mItemDb;
    private long mItemId;
    private Item mItem;
    public static final String EXTRA_ITEM_NAME = "com.sakiewicz.practicedatabase.item";
    public static final String EXTRA_ITEM_QUANTITY = "com.sakiewicz.practicedatabase.item";
    boolean isPermissionGranted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_edit);

        mItemName = findViewById(R.id.itemName);
        mItemQuantity = findViewById(R.id.quantityText);
        mItemGetName = getIntent().getStringExtra(EXTRA_ITEM_NAME);

        GetNumber();
        returnHome();



        mItemDb = ItemDatabase.getInstance(getApplicationContext());

        // Get question ID from QuestionActivity
        Intent intent = getIntent();
        mItemId = intent.getLongExtra(EXTRA_ITEM_ID, -1);

        ActionBar actionBar = getSupportActionBar();

        if (mItemId == -1) {
            // Add new item
            mItem = new Item();
            setTitle(R.string.add_item);
        }
        else {
            // Update existing item
            mItem = mItemDb.getItem(mItemId);
            mItemName.setText(mItem.getName());
            mItemQuantity.setText(mItem.getQuantity());


        }

    }

    public void saveButtonClick(View view) {

        mItem.setName(mItemName.getText().toString());
        mItem.setQuantity(mItemQuantity.getText().toString());
        String quantity = mItemQuantity.getText().toString();

        if (mItemId == -1) {
            // New item
            mItemDb.addItem(mItem);
        } else {
            // Existing item
            mItemDb.updateItem(mItem);
            if(number != null){
                if (number == "1"){
                    isPermissionGranted =false;
                }
                else{
                    isPermissionGranted = true;
                }
            }


            if ((number == "0") &&  (isPermissionGranted)){

                String smsText = "You are out of " + mItemName.getText().toString();
                SmsManager.getDefault().sendTextMessage(number, null, smsText, null, null);
                returnHome();
            }
            else if ((number == "0") && (!isPermissionGranted) ){
                //GetNumber();
                returnHome();
            }

            else if((number == "0") && (number == null)){
                showRequestPermissionsInfoAlertDialog(true);

            }
        }

        // Send back item ID
        Intent intent = new Intent();
        intent.putExtra(EXTRA_ITEM_ID, mItem.getId());
        setResult(RESULT_OK, intent);
        finish();
    }

    public void returnHome(){
        Intent home_intent = new Intent(getApplicationContext(), InventoryActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(home_intent);
    }



    public void GetNumber() {

        if (ActivityCompat.checkSelfPermission(this, READ_SMS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, READ_PHONE_NUMBERS) ==
                        PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            // Permission check

            // Create obj of TelephonyManager and ask for current telephone service
            TelephonyManager telephonyManager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
            String phone_number = telephonyManager.getLine1Number();

            number = phone_number;
            return;
        } else {
            number = "1";
            return;
        }
    }

    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 100:
                TelephonyManager telephonyManager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
                if (ActivityCompat.checkSelfPermission(this, READ_SMS) !=
                        PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                        READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED &&
                        ActivityCompat.checkSelfPermission(this, READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {

                    return;
                }


                number = telephonyManager.getLine1Number();
                isPermissionGranted = true;
                //number.setText(phoneNumber);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + requestCode);
        }
    }

    public boolean isPermissionGranted(){
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    public void showRequestPermissionsInfoAlertDialog(final boolean makeSystemRequest) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String permission_alert_dialog_title = "Permission Request";
        String permission_dialog_message = "Allow this app to access your messenger?";
        builder.setTitle(permission_alert_dialog_title); // Your own title
        builder.setMessage(permission_dialog_message); // Your own message

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                // Display system runtime permission request?
                if (makeSystemRequest) {
                    isPermissionGranted = true;
                    //getNumber();
                }
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                // Display system runtime permission request?
                if (makeSystemRequest) {
                    isPermissionGranted = false;
                    //getNumber();
                }
            }
        });

        builder.setCancelable(false);
        builder.show();
    }




}
